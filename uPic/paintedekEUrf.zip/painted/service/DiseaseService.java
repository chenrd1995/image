package cn.org.pgm.painted.service;

import cn.org.pgm.painted.domain.Disease;
import cn.org.pgm.painted.domain.PageBean;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.io.UnsupportedEncodingException;
import java.util.List;

public interface DiseaseService {
    public PageBean<Disease> findByPage(int currentPage, int pageSize, String diseaseClass );

    public HSSFWorkbook exportExcel(String numbers) throws UnsupportedEncodingException;

    public HSSFWorkbook exportExcelAll() throws UnsupportedEncodingException;

    public List<List<String>> groupCount(String groupName);

    public List<Disease> findByClass(String name,String diseaseClass);


}
