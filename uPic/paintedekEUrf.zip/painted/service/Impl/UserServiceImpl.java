package cn.org.pgm.painted.service.Impl;

import cn.org.pgm.painted.dao.Impl.UserDaoImpl;
import cn.org.pgm.painted.dao.UserDao;
import cn.org.pgm.painted.domain.User;
import cn.org.pgm.painted.service.UserService;

public class UserServiceImpl implements UserService {
    UserDao userDao = new UserDaoImpl();
    @Override
    public User findUser(String Username, String password) {
        return userDao.findUser(Username,password);
    }
}
