package cn.org.pgm.painted.service.Impl;

import cn.org.pgm.painted.dao.Impl.PaintedInfoDaoImpl;
import cn.org.pgm.painted.dao.PaintedInfoDao;
import cn.org.pgm.painted.domain.PageBean;
import cn.org.pgm.painted.domain.PaintedInfo;
import cn.org.pgm.painted.service.PaintedInfoService;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;


import javax.servlet.http.HttpServletResponse;
import javax.sound.midi.Soundbank;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static cn.org.pgm.painted.util.ExportExcel.excelExport;


public class PaintedInfoServiceImpl implements PaintedInfoService {
    private final PaintedInfoDao paintedInfoDao = new PaintedInfoDaoImpl();

    @Override
    public List<PaintedInfo> findAll() {
        List<PaintedInfo> paintedInfoList = null;
        paintedInfoList = paintedInfoDao.findAllPaintedInfo();
        return paintedInfoList;
    }

    @Override
    public PageBean<PaintedInfo> findByPage(int currentPage, int pageSize, String range, String direction, String location, String size) {
        System.out.println(location);
        //封装pageBean
        PageBean<PaintedInfo> pb = new PageBean<>();
        //设置当前页码
        pb.setCurrentPage(currentPage);
        //设置每页显示条数
        pb.setPageSize(pageSize);
        //设置总记录数
        int totalCount = paintedInfoDao.findTotalCount(range, direction, location, size);
        pb.setTotalCount(totalCount);
        //设置当前也显示的数据结合
        int start = (currentPage - 1) * pageSize;//开始的记录数

        List<PaintedInfo> list = paintedInfoDao.findByPage(start, pageSize, range, direction, location, size);
        pb.setList(list);
        //设置总页数 = 总记录数/每页显示条数
        int totalPage = totalCount % pageSize == 0 ? totalCount / pageSize : (totalCount / pageSize) + 1;
        pb.setTotalPage(totalPage);
        return pb;
    }

//    @Override
//    public HSSFWorkbook exportExcel(String numbers) throws UnsupportedEncodingException {
//        List<PaintedInfo> infos = paintedInfoDao.findByNumber(numbers);
//        Map<String, String> titleMap = excelTitle();
//        String sheetName = "信息导出";
//        return excelExport(infos, titleMap, sheetName);
//    }

    @Override
    public HSSFWorkbook exportExcelAll() throws UnsupportedEncodingException {
        List<PaintedInfo> infos = paintedInfoDao.findAllPaintedInfo();
        Map<String, String> titleMap = excelTitle();
        String sheetName = "信息导出";
        return excelExport(infos, titleMap, sheetName);
    }

    @Override
    public List<List<String>> groupCount(String groupName) {
        float totalCount = paintedInfoDao.findTotalCount("", "", "", "");
        List<Map<String, Object>> mapList = paintedInfoDao.countByGroupName(groupName);
        List<List<String>> lists = new ArrayList<>();
        for (Map<String, Object> map : mapList) {
            List<String> list = new ArrayList<>();
            for (String key : map.keySet()) {
                if (key.equals(groupName)) {
                    list.add(map.get(key).toString());
                }
                if (key.equals("count(*)")) {
                    Object obj = map.get(key).toString();
//                    int count = Integer.parseInt(obj.toString());
                    list.add(obj.toString());
                }

            }
            lists.add(list);
        }
        return lists;

    }

    @Override
    public List<PaintedInfo> findByValues(String build, String pClass, String history,String unit) {
        List<PaintedInfo> paintedInfoList = null;
        paintedInfoList = paintedInfoDao.findByValues(build,pClass,history,unit);
        return paintedInfoList;
    }

    @Override
    public PaintedInfo findByNumber(String number) {
        PaintedInfo info = null;
        info = paintedInfoDao.findByNumber(number);
        return info;
    }

    private Map<String, String> excelTitle() {
        Map<String, String> titleMap = new LinkedHashMap<String, String>();
        titleMap.put("painted_serial", "彩画序号");
        titleMap.put("painted_number", "彩画编号");
        titleMap.put("painted_class", "彩画类别");
        titleMap.put("painted_range", "彩画范围");
        titleMap.put("painted_direction", "彩画方向");
        titleMap.put("painted_location", "彩画位置");
        titleMap.put("painted_craft", "彩画工艺");
        titleMap.put("painted_history", "历史沿革");
        titleMap.put("painted_repair", "修缮管理");
        titleMap.put("painted_story", "彩画故事");
        titleMap.put("painted_build", "所属建筑");
        return titleMap;
    }

}
