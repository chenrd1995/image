package cn.org.pgm.painted.service.Impl;

import cn.org.pgm.painted.dao.BuildDao;
import cn.org.pgm.painted.dao.Impl.BuildDaoImpl;
import cn.org.pgm.painted.domain.Build;
import cn.org.pgm.painted.service.BuildService;

import java.util.List;

public class BuildServiceImpl implements BuildService {
    BuildDao buildDao = new BuildDaoImpl();

    @Override
    public Build findById(String id) {
        return buildDao.findById(id);
    }

    @Override
    public List<Build> findAll() {
        return buildDao.findAll();
    }
}
