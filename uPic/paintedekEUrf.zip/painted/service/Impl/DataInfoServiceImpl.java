package cn.org.pgm.painted.service.Impl;

import cn.org.pgm.painted.dao.DataInfoDao;
import cn.org.pgm.painted.dao.Impl.DataInfoImpl;
import cn.org.pgm.painted.domain.DataInfo;
import cn.org.pgm.painted.service.DataInfoService;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class DataInfoServiceImpl implements DataInfoService {
    DataInfoDao dataInfoDao = new DataInfoImpl();
    @Override
    public List<DataInfo> findByTypeAndPaintedName(String type, String PaintedName) {
        return dataInfoDao.findByTypeAndPaintedName(type,PaintedName);
    }

    @Override
    public List<List<String>> groupCount(String groupName) {
        List<Map<String, Object>> mapList = dataInfoDao.countByGroupName(groupName);
        List<List<String>> lists = new ArrayList<>();
        for (Map<String, Object> map : mapList) {
            List<String> list = new ArrayList<>();
            for (String key : map.keySet()) {
                if (key.equals(groupName)) {
                    list.add(map.get(key).toString());
                }
                if (key.equals("count(*)")) {
                    Object obj = map.get(key).toString();
                    String count = obj.toString();
                    list.add(count);
                }

            }
            lists.add(list);
        }
        return lists;
    }
}
