package cn.org.pgm.painted.service.Impl;

import cn.org.pgm.painted.dao.DiseaseDao;
import cn.org.pgm.painted.dao.Impl.DiseaseDaoImpl;
import cn.org.pgm.painted.domain.Disease;
import cn.org.pgm.painted.domain.PageBean;
import cn.org.pgm.painted.domain.PaintedInfo;
import cn.org.pgm.painted.service.DiseaseService;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static cn.org.pgm.painted.util.ExportExcel.excelExport;

public class DiseaseServiceImpl implements DiseaseService {
    private final DiseaseDao diseaseDao = new DiseaseDaoImpl();
    @Override
    public PageBean<Disease> findByPage(int currentPage, int pageSize, String diseaseClass) {
        //封装pageBean
        PageBean<Disease> pb = new PageBean<Disease>();
        //设置当前页码
        pb.setCurrentPage(currentPage);
        //设置每页显示条数
        pb.setPageSize(pageSize);
        //设置总记录数
        int totalCount = diseaseDao.findTotalCount(diseaseClass);
        pb.setTotalCount(totalCount);
        //设置当前也显示的数据结合
        int start = (currentPage - 1) * pageSize;//开始的记录数

        List<Disease> list = diseaseDao.findByPage(start, pageSize, diseaseClass);
        pb.setList(list);
        //设置总页数 = 总记录数/每页显示条数
        int totalPage = totalCount % pageSize == 0 ? totalCount / pageSize : (totalCount / pageSize) + 1;
        pb.setTotalPage(totalPage);
        return pb;
    }

    @Override
    public HSSFWorkbook exportExcel(String numbers) throws UnsupportedEncodingException {
        List<Disease> infos = diseaseDao.findByNumber(numbers);
        Map<String, String> titleMap = excelTitle();
        String sheetName = "信息导出";
        return excelExport(infos, titleMap, sheetName);
    }

    @Override
    public HSSFWorkbook exportExcelAll() throws UnsupportedEncodingException {
        List<Disease> diseaseList = diseaseDao.findByNumber("()");
        Map<String, String> titleMap = excelTitle();
        String sheetName = "信息导出";
        return excelExport(diseaseList, titleMap, sheetName);
    }

    @Override
    public List<List<String>> groupCount(String groupName) {
        List<Map<String, Object>> mapList = diseaseDao.countByGroupName(groupName);
        List<List<String>> lists = new ArrayList<>();
        for (Map<String, Object> map : mapList) {
            List<String> list = new ArrayList<>();
            for (String key : map.keySet()) {
                if (key.equals(groupName)) {
                    list.add(map.get(key).toString());
                }
                if (key.equals("count(*)")) {
                    Object obj = map.get(key).toString();
                    String count = obj.toString();
                    list.add(count);
                }

            }
            lists.add(list);
        }
        return lists;
    }

    @Override
    public List<Disease> findByClass(String name,String diseaseClass) {
        return diseaseDao.findByClass(name,diseaseClass);
    }

    private Map<String, String> excelTitle() {
        Map<String, String> titleMap = new LinkedHashMap<String, String>();
        titleMap.put("painted_serial", "彩画序号");
        titleMap.put("painted_number", "彩画编号");
        titleMap.put("disease_number", "病害编号");
        titleMap.put("disease_class", "病害类型");
        titleMap.put("disease_description", "病害描述");
        titleMap.put("painted_build", "所属建筑");
        titleMap.put("survey_date", "勘察时间");
        return titleMap;
    }
}
