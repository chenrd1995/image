package cn.org.pgm.painted.service.Impl;

import cn.org.pgm.painted.dao.AreaDao;
import cn.org.pgm.painted.dao.Impl.AreaDaoImpl;
import cn.org.pgm.painted.domain.Area;
import cn.org.pgm.painted.service.AreaService;

import java.util.List;

public class AreaServiceImpl implements AreaService {
    AreaDao areaDao = new AreaDaoImpl();

    @Override
    public Area findById(String id) {
        return areaDao.findById(id);
    }

    @Override
    public List<Area> findAll() {
        return areaDao.findAll();
    }
}
