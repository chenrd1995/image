package cn.org.pgm.painted.service;

import cn.org.pgm.painted.domain.User;

public interface UserService {
    public User findUser(String Username,String password);
}
