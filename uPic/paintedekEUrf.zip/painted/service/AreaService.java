package cn.org.pgm.painted.service;

import cn.org.pgm.painted.domain.Area;

import java.util.List;

public interface AreaService {

    public Area findById(String id);

    public List<Area> findAll();
}
