package cn.org.pgm.painted.service;

import cn.org.pgm.painted.domain.DataInfo;

import java.util.List;

public interface DataInfoService {
    /**
     * 数据查找
     * @param type 数据类型
     * @param PaintedName 彩画名称
     * @return 数据列表
     */
    public List<DataInfo> findByTypeAndPaintedName(String type, String PaintedName);

    /**
     * 类别统计
     * @param groupName 组名
     * @return 统计列表
     */
    public  List<List<String>> groupCount(String groupName);
}
