package cn.org.pgm.painted.service;

import cn.org.pgm.painted.domain.PageBean;
import cn.org.pgm.painted.domain.PaintedInfo;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;

public interface PaintedInfoService {
    /**
     * 所有彩画信息
     *
     * @return 所有彩画信息
     */
    public List<PaintedInfo> findAll();


    /**
     * 按照类型分页查询个数
     *
     * @param pageSize  每页多少个
     * @param range     范围
     * @param direction 方向
     * @param location  位置
     * @param size      大小
     * @return 分页彩画列表
     */
    public PageBean<PaintedInfo> findByPage(int currentPage, int pageSize, String range, String direction, String location, String size);

//    public HSSFWorkbook exportExcel(String numbers) throws UnsupportedEncodingException;

    public HSSFWorkbook exportExcelAll() throws UnsupportedEncodingException;

    public List<List<String>> groupCount(String groupName);

    public List<PaintedInfo> findByValues(String build,String pClass,String history,String unit);

    public PaintedInfo findByNumber(String number);

}
