package cn.org.pgm.painted.service;

import cn.org.pgm.painted.domain.Build;

import java.util.List;

public interface BuildService {
    /**
     * 数据查找 by Id
     *
     * @param id 建筑编号
     * @return 建筑
     */
    public Build findById(String id);

    /**
     * 所有区域资料
     *
     * @return 建筑列表
     */
    public List<Build> findAll();
}
