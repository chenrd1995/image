package cn.org.pgm.painted.web.servlet;

import cn.org.pgm.painted.domain.DataInfo;
import cn.org.pgm.painted.service.DataInfoService;
import cn.org.pgm.painted.service.Impl.DataInfoServiceImpl;
import cn.org.pgm.painted.util.ParameterUtils;
import org.w3c.dom.ls.LSInput;


import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/data/*")
public class DataInfoServlet extends BaseServlet {
    private final ParameterUtils parameterUtils = new ParameterUtils();
    private final DataInfoService dataInfoService = new DataInfoServiceImpl();

    public void find(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String typeStr = request.getParameter("type");
        typeStr = parameterUtils.Parameter2StrIn(typeStr);
        String paintedStr = request.getParameter("painted");
        paintedStr = parameterUtils.Parameter2StrIn(paintedStr);
        List<DataInfo> dataInfos = dataInfoService.findByTypeAndPaintedName(typeStr, paintedStr);
        writeValue(dataInfos, response);
    }

    public void countData(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String attrs = request.getParameter("attrs");
        List<List<String>> mapList = null;
        if (attrs != null && attrs.length() > 0) {
            mapList = dataInfoService.groupCount(attrs);
            writeValue(mapList, response);
        } else {
            writeValue(mapList, response);
        }
    }

    public void countFormatAndType(HttpServletRequest request, HttpServletResponse response) throws IOException {
        List<List<String>> FormatList = null;
        List<List<String>> TypeList = null;
        FormatList = dataInfoService.groupCount("data_format");
        TypeList = dataInfoService.groupCount("data_type");
        List<List<List<String>>> list = new ArrayList<>();
        list.add(FormatList);
        list.add(TypeList);
        writeValue(list, response);
    }

}
