package cn.org.pgm.painted.web.servlet;

import cn.org.pgm.painted.domain.Disease;
import cn.org.pgm.painted.domain.PageBean;
import cn.org.pgm.painted.service.DiseaseService;
import cn.org.pgm.painted.service.Impl.DiseaseServiceImpl;
import cn.org.pgm.painted.util.ParameterUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.UUID;

@WebServlet("/disease/*")
public class DiseaseServlet extends BaseServlet {
    private final DiseaseService diseaseService = new DiseaseServiceImpl();
    private final ParameterUtils parameterUtils = new ParameterUtils();

    public void findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //当前页
        String currentPageStr = request.getParameter("currentPage");
        int currentPage = parameterUtils.Parameter2Int(currentPageStr, 1);
        //条数
        String pageSizeStr = request.getParameter("pageSize");
        int pageSize = parameterUtils.Parameter2Int(pageSizeStr, 10);
        PageBean<Disease> pb = diseaseService.findByPage(currentPage, pageSize, "");
        writeValue(pb, response);
    }

    public void findByNumber(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String numberStr = request.getParameter("numbers");
        String currentPageStr = request.getParameter("currentPage");
        int currentPage = parameterUtils.Parameter2Int(currentPageStr, 1);
        String pageSizeStr = request.getParameter("pageSize");
        int pageSize = parameterUtils.Parameter2Int(pageSizeStr, 10);
        numberStr = parameterUtils.Parameter2StrIn(numberStr);
        HSSFWorkbook sheets = diseaseService.exportExcel(numberStr);
        responseExcel(response, sheets);
    }

    public void downloadAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HSSFWorkbook sheets = diseaseService.exportExcelAll();
        responseExcel(response, sheets);
    }

    public void staticDisease(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String attrs = request.getParameter("attrs");
        List<List<String>> mapList = null;
        if (attrs != null && attrs.length() > 0) {
            mapList = diseaseService.groupCount(attrs);
            writeValue(mapList, response);

        } else {
            writeValue(mapList, response);
        }
    }
    public void findByClass(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String disease_class = request.getParameter("disease_class");
        disease_class = parameterUtils.Parameter2StrIn(disease_class);
        String nameStr = request.getParameter("name");
        nameStr = parameterUtils.Parameter2StrIn(nameStr);
        List<Disease> ls = diseaseService.findByClass(nameStr,disease_class);
        writeValue(ls,response);
    }

    public void findByAttribute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String currentPageStr = request.getParameter("currentPage");
        int currentPage = parameterUtils.Parameter2Int(currentPageStr, 1);
        String pageSizeStr = request.getParameter("pageSize");
        int pageSize = parameterUtils.Parameter2Int(pageSizeStr, 20);
        String disease_class = request.getParameter("disease_class");
        disease_class = parameterUtils.Parameter2StrIn(disease_class);
        PageBean<Disease> pb = diseaseService.findByPage(currentPage, pageSize, disease_class);
        writeValue(pb, response);
    }

    private void responseExcel(HttpServletResponse response, HSSFWorkbook sheets) throws IOException {
        OutputStream output = response.getOutputStream();
        final String uuid = UUID.randomUUID().toString() + ".xls";
        String disposition = "attachment;filename=" + uuid;
        try {
            response.reset();
            response.setContentType("application/vnd.ms-excel");
            response.setHeader("Content-disposition", "attachment;filename=" + uuid);
            sheets.write(output);
            output.flush();
            output.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
