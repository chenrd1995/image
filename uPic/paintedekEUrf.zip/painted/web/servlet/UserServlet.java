package cn.org.pgm.painted.web.servlet;

import cn.org.pgm.painted.domain.ResultInfo;
import cn.org.pgm.painted.domain.User;
import cn.org.pgm.painted.service.Impl.UserServiceImpl;
import cn.org.pgm.painted.service.UserService;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

@WebServlet("/user/*")
public class UserServlet extends BaseServlet {
    private final UserService service = new UserServiceImpl();

    public void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Map<String, String[]> map = request.getParameterMap();
        SimpleDateFormat sdf = new SimpleDateFormat();// 格式化时间
        sdf.applyPattern("yyyy-MM-dd HH:mm:ss a");// a为am/pm的标记
        Date date = new Date();// 获取当前时间
        User user = new User();
        try {
            BeanUtils.populate(user, map);
        } catch (Exception e) {
            e.printStackTrace();
        }
        User u = service.findUser(user.getUsername(), user.getPassword());

        ResultInfo info = new ResultInfo();

        if (u == null) {
            //用户名密码或错误
            info.setFlag(false);
            info.setErrorMsg("用户名密码或错误");

        } else {
            request.getSession().setAttribute("user", u);
            info.setFlag(true);
        }
        writeValue(info, response);
    }
}
