package cn.org.pgm.painted.web.servlet;

import cn.org.pgm.painted.domain.Build;
import cn.org.pgm.painted.service.BuildService;
import cn.org.pgm.painted.service.Impl.BuildServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/build/*")
public class BuildServlet extends BaseServlet {
    private final BuildService service = new BuildServiceImpl();

    public void findById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("id");
        Build dataInfos = service.findById(id);
        writeValue(dataInfos, response);
    }

    public void findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Build> dataInfos = service.findAll();
        writeValue(dataInfos, response);
    }

}
