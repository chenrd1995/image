package cn.org.pgm.painted.web.servlet;

import cn.org.pgm.painted.domain.PageBean;
import cn.org.pgm.painted.domain.PaintedInfo;
import cn.org.pgm.painted.domain.ResultInfo;
import cn.org.pgm.painted.service.Impl.PaintedInfoServiceImpl;
import cn.org.pgm.painted.service.PaintedInfoService;
import cn.org.pgm.painted.util.ParameterUtils;
import cn.org.pgm.painted.util.UploadUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.io.*;
import java.util.Collection;
import java.util.UUID;
import java.util.List;

@MultipartConfig
@WebServlet("/paintedInfo/*")
public class PaintedInfoServlet extends BaseServlet {
    private final PaintedInfoService paintedInfoService = new PaintedInfoServiceImpl();
    private final ParameterUtils parameterUtils = new ParameterUtils();

    public void findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //当前页
        String currentPageStr = request.getParameter("currentPage");
        int currentPage = parameterUtils.Parameter2Int(currentPageStr, 1);
        //条数
        String pageSizeStr = request.getParameter("pageSize");
        int pageSize = parameterUtils.Parameter2Int(pageSizeStr, 5);
        PageBean<PaintedInfo> pb = paintedInfoService.findByPage(currentPage, pageSize, "", "", "", "");
        writeValue(pb, response);
    }

    public void findByAttribute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String currentPageStr = request.getParameter("currentPage");
        int currentPage = parameterUtils.Parameter2Int(currentPageStr, 1);
        String pageSizeStr = request.getParameter("pageSize");
        int pageSize = parameterUtils.Parameter2Int(pageSizeStr, 5);

        String rangeStr = request.getParameter("range");
        String directionStr = request.getParameter("direction");
        String locationStr = request.getParameter("location");
        String sizeStr = request.getParameter("size");
        rangeStr = parameterUtils.Parameter2StrIn(rangeStr);
        directionStr = parameterUtils.Parameter2StrIn(directionStr);
        locationStr = parameterUtils.Parameter2StrIn(locationStr);
        sizeStr = parameterUtils.Parameter2StrIn(sizeStr);

        PageBean<PaintedInfo> pb = paintedInfoService.findByPage(currentPage, pageSize, rangeStr, directionStr, locationStr, sizeStr);
        writeValue(pb, response);
    }

    public void findByNumber(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String numberStr = request.getParameter("number");
        numberStr = parameterUtils.Parameter2Str(numberStr);
        PaintedInfo info = paintedInfoService.findByNumber(numberStr);
        writeValue(info, response);
    }

    public void downloadAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HSSFWorkbook sheets = paintedInfoService.exportExcelAll();
        responseExcel(response, sheets);

    }

    public void staticPainted(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String attrs = request.getParameter("attrs");
        List<List<String>> mapList = null;
        if (attrs != null && attrs.length() > 0) {
            mapList = paintedInfoService.groupCount(attrs);
            writeValue(mapList, response);

        } else {
            writeValue(mapList, response);
        }
    }

    public void findByValues(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String buildStr = request.getParameter("build");
        String pClassStr = request.getParameter("pClass");
        String historyStr = request.getParameter("history");
        String unitStr = request.getParameter("unit");
        buildStr = parameterUtils.Parameter2StrIn(buildStr);
        pClassStr = parameterUtils.Parameter2StrIn(pClassStr);
        historyStr = parameterUtils.Parameter2StrIn(historyStr);
        unitStr = parameterUtils.Parameter2StrIn(unitStr);
        ResultInfo resultInfo = null;
        List<PaintedInfo> info = paintedInfoService.findByValues(buildStr, pClassStr, historyStr, unitStr);
        System.out.println(buildStr);
        System.out.println(pClassStr);
        System.out.println(historyStr);
        System.out.println(unitStr);
//        resultInfo.setData(info);
        writeValue(info, response);

    }
    public void upFile(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 获取文件上传组件
        Part part = request.getPart("files");

        // 获取文件的路径
        String header = part.getHeader("Content-Disposition");
        String path = header.substring(header.indexOf("filename=") + 10, header.length() - 1);
        // 获取文件名
        String name = UploadUtils.getRealName(path);
        // 获取文件的存放目录
        String realPath = this.getServletContext().getRealPath("/upload/");
        File file = new File(realPath);
        if (!file.exists()) {
            file.mkdirs();
        }
        // 对拷流
        InputStream inputStream = part.getInputStream();
        FileOutputStream outputStream = new FileOutputStream(new File(file, name));
        int len = -1;
        byte[] bytes = new byte[1024];
        while ((len = inputStream.read(bytes)) != -1) {
            outputStream.write(bytes, 0, len);
        }

        // 关闭资源
        outputStream.close();
        inputStream.close();

        // 删除临时文件
        part.delete();
        response.setContentType("text/html;charset=utf-8");
        response.getWriter().print("文件" + name + "上传成功！");
    }

    private void responseExcel(HttpServletResponse response, HSSFWorkbook sheets) throws IOException {
        OutputStream output = response.getOutputStream();
        final String uuid = UUID.randomUUID().toString() + ".xls";
        String disposition = "attachment;filename=" + uuid;
        try {
            response.reset();
            response.setContentType("application/vnd.ms-excel");
            response.setHeader("Content-disposition", "attachment;filename=" + uuid);
            sheets.write(output);
            output.flush();
            output.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }




}

