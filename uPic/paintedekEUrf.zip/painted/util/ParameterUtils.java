package cn.org.pgm.painted.util;

import java.io.UnsupportedEncodingException;

public class ParameterUtils {
    public int Parameter2Int(String str, int defaultValue) {
        int number = 0;//当前页码，如果不传递，则默认为第一页
        if (str != null && str.length() > 0) {
            number = Integer.parseInt(str);
        } else {
            number = defaultValue;
        }
        return number;
    }

    public String Parameter2Str(String parameter) {
        String str = "";
        if(parameter !=null){
        try {
            str = new String(parameter.getBytes("iso-8859-1"), "utf-8");
            return str;
        } catch (UnsupportedEncodingException e) {
            return str;
        }
        }
        else {
            return str;
        }
    }

    public String Parameter2StrIn(String parameter) {
        String str = Parameter2Str(parameter);
        return str.replaceAll("\"", "'").replaceAll("\\[", "(").replaceAll("]", ")");
    }
}
