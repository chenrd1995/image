package cn.org.pgm.painted.dao.Impl;

import cn.org.pgm.painted.dao.BuildDao;
import cn.org.pgm.painted.domain.Build;
import cn.org.pgm.painted.util.JDBCUtils;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;

public class BuildDaoImpl implements BuildDao {
    private final JdbcTemplate template = new JdbcTemplate(JDBCUtils.getDataSource());

    @Override
    public Build findById(String id) {
        Build build = null;
        String sql = "select * from gwf_build where build_id = ?";
        try {
            build = template.queryForObject(sql, new BeanPropertyRowMapper<Build>(Build.class), id);
        } catch (Exception ignored) {
        }
        return build;
    }

    @Override
    public List<Build> findAll() {
        String sql = "select * from gwf_build";
        return template.query(sql, new BeanPropertyRowMapper<Build>(Build.class));
    }
}
