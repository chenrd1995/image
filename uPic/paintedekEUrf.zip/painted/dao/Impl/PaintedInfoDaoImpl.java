package cn.org.pgm.painted.dao.Impl;

import cn.org.pgm.painted.dao.PaintedInfoDao;
import cn.org.pgm.painted.domain.PaintedInfo;
import cn.org.pgm.painted.util.JDBCUtils;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sound.midi.Soundbank;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class PaintedInfoDaoImpl implements PaintedInfoDao {
    private final JdbcTemplate template = new JdbcTemplate(JDBCUtils.getDataSource());

    @Override
    public List<PaintedInfo> findAllPaintedInfo() {
        String sql = "select * from gwf_painted";
        return template.query(sql, new BeanPropertyRowMapper<PaintedInfo>(PaintedInfo.class));
    }

    @Override
    public List<PaintedInfo> findByValues(String build, String pClass, String history,String unit) {
        String sql = "select * from gwf_painted where 1=1 ";
        StringBuilder sb = new StringBuilder(sql);
        //2.判断参数是否有值
        if (!build.equals("()") && build.length() >= 2) {
            sb.append(" and painted_build in ").append(build);
        }
        if (!pClass.equals("()") && pClass.length() >= 2) {
            sb.append(" and painted_class in ").append(pClass);
        }
        if (!history.equals("()") && history.length() >= 2) {
            sb.append(" and painted_history in ").append(history);
        }
        if (!unit.equals("()") && unit.length() >= 2) {
            sb.append(" and painted_unit in ").append(unit);
        }
        sql = sb.toString();
        System.out.println(sql);
        return template.query(sql, new BeanPropertyRowMapper<PaintedInfo>(PaintedInfo.class));
    }

    @Override
    public int findTotalCount(String range, String direction, String location, String size) {
        String sql = "select count(*) from gwf_painted where 1=1";
        StringBuilder sb = new StringBuilder(sql);
        //2.判断参数是否有值
        if (!range.equals("()") && range.length() >= 2) {
            sb.append(" and painted_range in ").append(range);
        }
        if (!direction.equals("()") && direction.length() >= 2) {
            sb.append(" and painted_direction in ").append(direction);
        }
        if (!location.equals("()") && location.length() >= 2) {
            sb.append(" and painted_location in ").append(location);
        }
        if (!size.equals("()") && size.length() >= 2) {
            sb.append(" and painted_size in ").append(size);
        }
        sql = sb.toString();
        System.out.println(sql);
        return template.queryForObject(sql, Integer.class);

    }

    @Override
    public List<PaintedInfo> findByPage(int start, int pageSize, String range, String direction, String location, String size) {
        String sql = "select * from gwf_painted where 1=1";
        StringBuilder sb = new StringBuilder(sql);
        List params = new ArrayList();//条件们
        //2.判断参数是否有值
        if (!range.equals("()") && range.length() >=2) {
            sb.append(" and painted_range in ").append(range);
        }
        if (!direction.equals("()") && direction.length() >= 2) {
            sb.append(" and painted_direction in ").append(direction);
        }
        if (!location.equals("()") && location.length() >= 2) {
            sb.append(" and painted_location in ").append(location);
        }
        if (!size.equals("()") && size.length() >= 2) {
            sb.append(" and painted_size in ").append(size);
        }
        sb.append(" limit ? , ? ");//分页条件
        sql = sb.toString();
        params.add(start);
        params.add(pageSize);
        return template.query(sql, new BeanPropertyRowMapper<PaintedInfo>(PaintedInfo.class),params.toArray());
    }

    @Override
    public PaintedInfo findByNumber(String numbers) {
        String sql = "select * from gwf_painted where painted_number = '"+numbers+"'";
        return template.queryForObject(sql, new BeanPropertyRowMapper<PaintedInfo>(PaintedInfo.class));
    }

    @Override
    public List<Map<String, Object>> countByGroupName(String GroupName) {
        String sql = String.format("select %s,count(*) from gwf_painted group by %s",GroupName,GroupName);
        return template.queryForList(sql);
    }

    @Override
    public boolean update(PaintedInfo info) {
//
//        String sql = "Insert Into `gwf_painted`" +
//                " (" +
//                "`painted_serial` , " +
//                "`painted_number` , " +
//                "`painted_class` , " +
//                "`painted_range` , " +
//                "`painted_direction` , " +
//                "`painted_location` , " +
//                "`painted_size` , " +
//                "`painted_craft` , " +
//                "`painted_history` , " +
//                "`painted_repair` , " +
//                "`painted_story` , " +
//                "`painted_build` , " +
//                "`area_name` , " +
//                "`area_number` , " +
//                "`build_number` , " +
//                "`painted_degree` , " +
//                "`painted_unit`" +
//                ") values " +
//                "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
//        template.update(sql)
        return false;
    }

//    @Override
//    public PaintedInfo findById(String painted_serial) {
//        String sql = "select * from gwf_painted where painted_serial = ?";
//        return template.queryForObject(sql, new BeanPropertyRowMapper<PaintedInfo>(PaintedInfo.class));
//    }
}
