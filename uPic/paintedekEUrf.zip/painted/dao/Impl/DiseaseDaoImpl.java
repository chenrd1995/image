package cn.org.pgm.painted.dao.Impl;

import cn.org.pgm.painted.dao.DiseaseDao;
import cn.org.pgm.painted.domain.Disease;
import cn.org.pgm.painted.util.JDBCUtils;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class DiseaseDaoImpl implements DiseaseDao {
    private final JdbcTemplate template = new JdbcTemplate(JDBCUtils.getDataSource());

    @Override
    public List<Disease> findByPage(int start, int pageSize, String diseaseClass) {
        String sql = "select * from painted_disease where 1=1";
        StringBuilder sb = new StringBuilder(sql);
        List params = new ArrayList();//条件们
        //2.判断参数是否有值
        if (!diseaseClass.equals("()") && diseaseClass.length() >= 2) {
            sb.append(" and disease_class in ").append(diseaseClass);
        }
        sb.append(" limit ? , ? ");//分页条件
        sql = sb.toString();
        params.add(start);
        params.add(pageSize);
        return template.query(sql, new BeanPropertyRowMapper<Disease>(Disease.class), params.toArray());
    }

    @Override
    public int findTotalCount(String diseaseClass) {
        String sql = "select count(*) from painted_disease where 1=1 ";
        StringBuilder sb = new StringBuilder(sql);
        //2.判断参数是否有值
        if (!diseaseClass.equals("()") && diseaseClass.length() >= 2) {
            sb.append(" and disease_class in ").append(diseaseClass);
        }
        sql = sb.toString();
        return template.queryForObject(sql, Integer.class);
    }

    @Override
    public List<Disease> findByClass(String name,String diseaseClass) {
        String sql = "select * from painted_disease where 1=1 ";
        StringBuilder sb = new StringBuilder(sql);
        if (!name.equals("()") && name.length() > 2) {
            sb.append(" and painted_number like ").append(name);
        }
        if (!diseaseClass.equals("()") && diseaseClass.length() >= 2) {
            sb.append(" and disease_class in ").append(diseaseClass);
        }
        sql = sb.toString();
        return template.query(sql,new BeanPropertyRowMapper<Disease>(Disease.class));
    }

    @Override
    public List<Disease> findByNumber(String numbers) {
        String sql = "select * from painted_disease where 1=1";
        StringBuilder sb = new StringBuilder(sql);
        if (!numbers.equals("()") && numbers.length() >=2) {
            sb.append(" and disease_number in ").append(numbers);
        }
        sql = sb.toString();
        return template.query(sql, new BeanPropertyRowMapper<Disease>(Disease.class));
    }

    @Override
    public List<Map<String, Object>> countByGroupName(String GroupName) {
        String sql = String.format("select %s,count(*) from painted_disease group by %s",GroupName,GroupName);
        return template.queryForList(sql);
    }
}
