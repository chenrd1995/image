package cn.org.pgm.painted.dao.Impl;

import cn.org.pgm.painted.dao.UserDao;
import cn.org.pgm.painted.domain.User;
import cn.org.pgm.painted.util.JDBCUtils;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;


public class UserDaoImpl implements UserDao {
    private final JdbcTemplate template = new JdbcTemplate(JDBCUtils.getDataSource());

    @Override
    public User findUser(String username, String password) {
        User user = null;
        String sql = "select * from gwf_user where username = ? and password = ?";
        try {
            user = template.queryForObject(sql, new BeanPropertyRowMapper<User>(User.class), username, password);
        } catch (Exception ignored) {

        }
        return user;
    }
}
