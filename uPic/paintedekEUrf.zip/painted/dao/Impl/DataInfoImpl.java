package cn.org.pgm.painted.dao.Impl;

import cn.org.pgm.painted.dao.DataInfoDao;
import cn.org.pgm.painted.domain.DataInfo;
import cn.org.pgm.painted.util.JDBCUtils;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;
import java.util.Map;

public class DataInfoImpl implements DataInfoDao {
    private final JdbcTemplate template = new JdbcTemplate(JDBCUtils.getDataSource());

    @Override
    public List<DataInfo> findByTypeAndPaintedName(String type, String PaintedName) {
        String sql = "select * from painted_data where 1=1";
        StringBuilder sb = new StringBuilder(sql);
        if (!PaintedName.equals("'%%'") && PaintedName.length() > 4) {
            sb.append(" and painted_number like ").append(PaintedName);
        }
        if (!type.equals("()") && type.length() >= 2) {
            sb.append(" and data_type in ").append(type);
        }
        sql = sb.toString();
        return template.query(sql, new BeanPropertyRowMapper<DataInfo>(DataInfo.class));
    }

    @Override
    public List<Map<String, Object>> countByGroupName(String groupName) {
        String sql = String.format("select %s,count(*) from painted_data group by %s", groupName, groupName);
        System.out.println(sql);
        return template.queryForList(sql);
    }
}
