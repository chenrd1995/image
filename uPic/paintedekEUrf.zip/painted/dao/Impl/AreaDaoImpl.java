package cn.org.pgm.painted.dao.Impl;

import cn.org.pgm.painted.dao.AreaDao;
import cn.org.pgm.painted.domain.Area;
import cn.org.pgm.painted.util.JDBCUtils;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;

public class AreaDaoImpl implements AreaDao {

    private final JdbcTemplate template = new JdbcTemplate(JDBCUtils.getDataSource());

    @Override
    public Area findById(String id) {
        Area area = null;
        String sql = "select * from gwf_area where area_id = ?";
        try {
            area = template.queryForObject(sql, new BeanPropertyRowMapper<Area>(Area.class), id);
        } catch (Exception ignored) {
        }
        return area;
    }

    @Override
    public List<Area> findAll() {
        String sql = "select * from gwf_area";
        return template.query(sql, new BeanPropertyRowMapper<Area>(Area.class));
    }
}
