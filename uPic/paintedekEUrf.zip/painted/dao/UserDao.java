package cn.org.pgm.painted.dao;

import cn.org.pgm.painted.domain.User;

public interface UserDao {
 User findUser(String username,String password);
}
