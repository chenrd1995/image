package cn.org.pgm.painted.dao;


import cn.org.pgm.painted.domain.Area;

import java.util.List;

public interface AreaDao {

    /**
     * 数据查找 by Id
     *
     * @param id 区域编号
     * @return 区域
     */
    public Area findById(String id);

    /**
     * 所有区域资料
     *
     * @return 区域列表
     */
    public List<Area> findAll();
}
