package cn.org.pgm.painted.dao;


import cn.org.pgm.painted.domain.PaintedInfo;

import java.util.List;
import java.util.Map;

public interface PaintedInfoDao {
    /**
     * 查询全部
     *
     * @return 整个彩画列表
     */
    public List<PaintedInfo> findAllPaintedInfo();


    /**
     * @param build   建筑
     * @param pClass  彩画类别
     * @param history 年代
     * @param unit    构件
     * @return 彩画信息列表
     */
    public List<PaintedInfo> findByValues(String build, String pClass, String history, String unit);

    /**
     * 按照类型查询个数
     *
     * @param range     范围
     * @param direction 方向
     * @param location  位置
     * @param size      大小
     * @return 彩画个数
     */
    public int findTotalCount(String range, String direction, String location, String size);

    /**
     * 按照类型分页查询个数
     *
     * @param start     起始位置
     * @param pageSize  每页多少个
     * @param range     范围
     * @param direction 方向
     * @param location  位置
     * @param size      大小
     * @return 分页彩画列表
     */
    public List<PaintedInfo> findByPage(int start, int pageSize, String range, String direction, String location, String size);

    /**
     * 按照彩绘编号查询
     *
     * @param numbers 彩绘编号
     * @return 彩绘列表
     */
    public PaintedInfo findByNumber(String numbers);

    /**
     * 个数统计
     *
     * @param GroupName 统计类别
     * @return 类别个数 map
     */
    public List<Map<String, Object>> countByGroupName(String GroupName);

    /**
     * 上传数据
     *
     * @param info 彩画信息
     * @return 是否上传成功
     */
    public boolean update(PaintedInfo info);
}
