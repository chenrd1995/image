package cn.org.pgm.painted.dao;

import cn.org.pgm.painted.domain.Disease;
import cn.org.pgm.painted.domain.PaintedInfo;

import java.util.List;
import java.util.Map;

public interface DiseaseDao {

    /**
     * 按照类型分页查询个数
     *
     * @param start     起始位置
     * @param pageSize  每页多少
     * @param diseaseClass   病害类型
     * @return 分页病害列表
     */
    public List<Disease> findByPage(int start, int pageSize,String diseaseClass);

    /**
     * 按照类型查询个数
     *
     * @param diseaseClass   病害类型
     * @return 病害个数
     */
    public int findTotalCount(String diseaseClass);

    public List<Disease> findByClass(String name ,String diseaseClass);

    public List<Disease> findByNumber(String numbers);

    public List<Map<String, Object>> countByGroupName(String GroupName);
}
