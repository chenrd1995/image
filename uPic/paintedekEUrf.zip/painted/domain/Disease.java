package cn.org.pgm.painted.domain;

public class Disease {
    private int disease_id;
    private String disease_number;
    private String disease_class;
    private String painted_serial;
    private String painted_number;
    private String painted_build;
    private String disease_description;
    private String survey_date;

    public Disease() {
    }

    public Disease(int disease_id, String disease_number, String disease_class, String disease_surveyDate, String painted_serial, String painted_number, String painted_build, String disease_description, String survey_date) {
        this.disease_id = disease_id;
        this.disease_number = disease_number;
        this.disease_class = disease_class;
        this.painted_serial = painted_serial;
        this.painted_number = painted_number;
        this.painted_build = painted_build;
        this.disease_description = disease_description;
        this.survey_date = survey_date;
    }

    public int getDisease_id() {
        return disease_id;
    }

    public void setDisease_id(int disease_id) {
        this.disease_id = disease_id;
    }

    public String getDisease_number() {
        return disease_number;
    }

    public void setDisease_number(String disease_number) {
        this.disease_number = disease_number;
    }

    public String getDisease_class() {
        return disease_class;
    }

    public void setDisease_class(String disease_class) {
        this.disease_class = disease_class;
    }

    public String getPainted_serial() {
        return painted_serial;
    }

    public void setPainted_serial(String painted_serial) {
        this.painted_serial = painted_serial;
    }

    public String getPainted_number() {
        return painted_number;
    }

    public void setPainted_number(String painted_number) {
        this.painted_number = painted_number;
    }

    public String getPainted_build() {
        return painted_build;
    }

    public void setPainted_build(String painted_build) {
        this.painted_build = painted_build;
    }

    public String getDisease_description() {
        return disease_description;
    }

    public void setDisease_description(String disease_description) {
        this.disease_description = disease_description;
    }

    public String getSurvey_date() {
        return survey_date;
    }

    public void setSurvey_date(String survey_date) {
        this.survey_date = survey_date;
    }
}
