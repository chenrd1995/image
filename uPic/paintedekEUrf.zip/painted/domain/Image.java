package cn.org.pgm.painted.domain;

import java.util.Date;

public class Image {
    private String img_QZH;
    private String img_BGQX;
    private String img_FILE_OLD;
    private String img_FILE_NEW;
    private String img_ND;
    private String img_BM;
    private String img_ZPZH;
    private String img_ZH;
    private String img_CJH;
    private String img_SYZ;
    private Date img_SJ;
    private String img_ZTM;
    private String img_WZSM;
    private String img_WJGS;
    private String img_WJCCLJ;
    private String img_KFZT;

    public Image() {
    }

    public Image(String img_QZH, String img_BGQX, String img_FILE_OLD, String img_FILE_NEW, String img_ND, String img_BM, String img_ZPZH, String img_ZH, String img_CJH, String img_SYZ, Date img_SJ, String img_ZTM, String img_WZSM, String img_WJGS, String img_WJCCLJ, String img_KFZT) {
        this.img_QZH = img_QZH;
        this.img_BGQX = img_BGQX;
        this.img_FILE_OLD = img_FILE_OLD;
        this.img_FILE_NEW = img_FILE_NEW;
        this.img_ND = img_ND;
        this.img_BM = img_BM;
        this.img_ZPZH = img_ZPZH;
        this.img_ZH = img_ZH;
        this.img_CJH = img_CJH;
        this.img_SYZ = img_SYZ;
        this.img_SJ = img_SJ;
        this.img_ZTM = img_ZTM;
        this.img_WZSM = img_WZSM;
        this.img_WJGS = img_WJGS;
        this.img_WJCCLJ = img_WJCCLJ;
        this.img_KFZT = img_KFZT;
    }

    public String getImg_QZH() {
        return img_QZH;
    }

    public void setImg_QZH(String img_QZH) {
        this.img_QZH = img_QZH;
    }

    public String getImg_BGQX() {
        return img_BGQX;
    }

    public void setImg_BGQX(String img_BGQX) {
        this.img_BGQX = img_BGQX;
    }

    public String getImg_FILE_OLD() {
        return img_FILE_OLD;
    }

    public void setImg_FILE_OLD(String img_FILE_OLD) {
        this.img_FILE_OLD = img_FILE_OLD;
    }

    public String getImg_FILE_NEW() {
        return img_FILE_NEW;
    }

    public void setImg_FILE_NEW(String img_FILE_NEW) {
        this.img_FILE_NEW = img_FILE_NEW;
    }

    public String getImg_ND() {
        return img_ND;
    }

    public void setImg_ND(String img_ND) {
        this.img_ND = img_ND;
    }

    public String getImg_BM() {
        return img_BM;
    }

    public void setImg_BM(String img_BM) {
        this.img_BM = img_BM;
    }

    public String getImg_ZPZH() {
        return img_ZPZH;
    }

    public void setImg_ZPZH(String img_ZPZH) {
        this.img_ZPZH = img_ZPZH;
    }

    public String getImg_ZH() {
        return img_ZH;
    }

    public void setImg_ZH(String img_ZH) {
        this.img_ZH = img_ZH;
    }

    public String getImg_CJH() {
        return img_CJH;
    }

    public void setImg_CJH(String img_CJH) {
        this.img_CJH = img_CJH;
    }

    public String getImg_SYZ() {
        return img_SYZ;
    }

    public void setImg_SYZ(String img_SYZ) {
        this.img_SYZ = img_SYZ;
    }

    public Date getImg_SJ() {
        return img_SJ;
    }

    public void setImg_SJ(Date img_SJ) {
        this.img_SJ = img_SJ;
    }

    public String getImg_ZTM() {
        return img_ZTM;
    }

    public void setImg_ZTM(String img_ZTM) {
        this.img_ZTM = img_ZTM;
    }

    public String getImg_WZSM() {
        return img_WZSM;
    }

    public void setImg_WZSM(String img_WZSM) {
        this.img_WZSM = img_WZSM;
    }

    public String getImg_WJGS() {
        return img_WJGS;
    }

    public void setImg_WJGS(String img_WJGS) {
        this.img_WJGS = img_WJGS;
    }

    public String getImg_WJCCLJ() {
        return img_WJCCLJ;
    }

    public void setImg_WJCCLJ(String img_WJCCLJ) {
        this.img_WJCCLJ = img_WJCCLJ;
    }

    public String getImg_KFZT() {
        return img_KFZT;
    }

    public void setImg_KFZT(String img_KFZT) {
        this.img_KFZT = img_KFZT;
    }
}
