package cn.org.pgm.painted.domain;

public class User {
    private int user_id;
    private String username;
    private String password;
    private String submission_date;
    private int user_authority;

    public User() {
    }

    public User(int user_id, String username, String password, String submission_date, int user_authority) {
        this.user_id = user_id;
        this.username = username;
        this.password = password;
        this.submission_date = submission_date;
        this.user_authority = user_authority;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getSubmission_date() {
        return submission_date;
    }

    public void setSubmission_date(String submission_date) {
        this.submission_date = submission_date;
    }

    public int getUser_authority() {
        return user_authority;
    }

    public void setUser_authority(int user_authority) {
        this.user_authority = user_authority;
    }

}
