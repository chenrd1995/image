package cn.org.pgm.painted.domain;

public class Build {
    private String build_id;
    private String build_name;
    private String area_number;

    public String getBuild_id() {
        return build_id;
    }

    public void setBuild_id(String build_id) {
        this.build_id = build_id;
    }

    public String getBuild_name() {
        return build_name;
    }

    public void setBuild_name(String build_name) {
        this.build_name = build_name;
    }

    public String getArea_number() {
        return area_number;
    }

    public void setArea_number(String area_number) {
        this.area_number = area_number;
    }

    public Build() {
    }

    public Build(String build_id, String build_name, String area_number) {
        this.build_id = build_id;
        this.build_name = build_name;
        this.area_number = area_number;
    }
}
