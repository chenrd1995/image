package cn.org.pgm.painted.domain;

public class PaintedInfo {
    private int painted_id;
    private String painted_serial;
    private String painted_number;
    private String painted_class;
    private String painted_range;
    private String painted_direction;
    private String painted_location;
    private String painted_size;
    private String painted_craft;
    private String painted_history;
    private String painted_repair;
    private String painted_story;
    private String painted_build;
    private String area_name;
    private String area_number;
    private String build_number;
    private String painted_degree;
    private String painted_unit;

    public int getPainted_id() {
        return painted_id;
    }

    public void setPainted_id(int painted_id) {
        this.painted_id = painted_id;
    }

    public String getPainted_serial() {
        return painted_serial;
    }

    public void setPainted_serial(String painted_serial) {
        this.painted_serial = painted_serial;
    }

    public String getPainted_number() {
        return painted_number;
    }

    public void setPainted_number(String painted_number) {
        this.painted_number = painted_number;
    }

    public String getPainted_class() {
        return painted_class;
    }

    public void setPainted_class(String painted_class) {
        this.painted_class = painted_class;
    }

    public String getPainted_range() {
        return painted_range;
    }

    public void setPainted_range(String painted_range) {
        this.painted_range = painted_range;
    }

    public String getPainted_direction() {
        return painted_direction;
    }

    public void setPainted_direction(String painted_direction) {
        this.painted_direction = painted_direction;
    }

    public String getPainted_location() {
        return painted_location;
    }

    public void setPainted_location(String painted_location) {
        this.painted_location = painted_location;
    }

    public String getPainted_size() {
        return painted_size;
    }

    public void setPainted_size(String painted_size) {
        this.painted_size = painted_size;
    }

    public String getPainted_craft() {
        return painted_craft;
    }

    public void setPainted_craft(String painted_craft) {
        this.painted_craft = painted_craft;
    }

    public String getPainted_history() {
        return painted_history;
    }

    public void setPainted_history(String painted_history) {
        this.painted_history = painted_history;
    }

    public String getPainted_repair() {
        return painted_repair;
    }

    public void setPainted_repair(String painted_repair) {
        this.painted_repair = painted_repair;
    }

    public String getPainted_story() {
        return painted_story;
    }

    public void setPainted_story(String painted_story) {
        this.painted_story = painted_story;
    }

    public String getPainted_build() {
        return painted_build;
    }

    public void setPainted_build(String painted_build) {
        this.painted_build = painted_build;
    }

    public String getArea_name() {
        return area_name;
    }

    public void setArea_name(String area_name) {
        this.area_name = area_name;
    }

    public String getArea_number() {
        return area_number;
    }

    public void setArea_number(String area_number) {
        this.area_number = area_number;
    }

    public String getBuild_number() {
        return build_number;
    }

    public void setBuild_number(String build_number) {
        this.build_number = build_number;
    }

    public String getPainted_degree() {
        return painted_degree;
    }

    public void setPainted_degree(String painted_degree) {
        this.painted_degree = painted_degree;
    }


    public String getPainted_unit() {
        return painted_unit;
    }

    public void setPainted_unit(String painted_unit) {
        this.painted_unit = painted_unit;
    }

    public PaintedInfo(int painted_id, String painted_serial, String painted_number, String painted_class, String painted_range, String painted_direction, String painted_location, String painted_size, String painted_craft, String painted_history, String painted_repair, String painted_story, String painted_build, String area_name, String area_number, String build_number, String painted_degree, String painted_unit) {
        this.painted_id = painted_id;
        this.painted_serial = painted_serial;
        this.painted_number = painted_number;
        this.painted_class = painted_class;
        this.painted_range = painted_range;
        this.painted_direction = painted_direction;
        this.painted_location = painted_location;
        this.painted_size = painted_size;
        this.painted_craft = painted_craft;
        this.painted_history = painted_history;
        this.painted_repair = painted_repair;
        this.painted_story = painted_story;
        this.painted_build = painted_build;
        this.area_name = area_name;
        this.area_number = area_number;
        this.build_number = build_number;
        this.painted_degree = painted_degree;
        this.painted_unit = painted_unit;
    }
}
