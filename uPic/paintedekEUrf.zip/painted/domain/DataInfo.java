package cn.org.pgm.painted.domain;

public class DataInfo {
    private String data_id;
    private String data_dir;
    private String data_file;
    private String data_type;
    private String data_format;
    private String area_name;
    private String area_number;
    private String build_name;
    private String build_number;
    private String painted_numbers;
    private String data_description;

    public DataInfo() {
    }

    public DataInfo(String data_id, String data_dir, String data_file, String data_type, String data_format, String area_name, String area_number, String build_name, String build_number, String painted_numbers, String data_description) {
        this.data_id = data_id;
        this.data_dir = data_dir;
        this.data_file = data_file;
        this.data_type = data_type;
        this.data_format = data_format;
        this.area_name = area_name;
        this.area_number = area_number;
        this.build_name = build_name;
        this.build_number = build_number;
        this.painted_numbers = painted_numbers;
        this.data_description = data_description;
    }

    public String getData_id() {
        return data_id;
    }

    public void setData_id(String data_id) {
        this.data_id = data_id;
    }

    public String getData_dir() {
        return data_dir;
    }

    public void setData_dir(String data_dir) {
        this.data_dir = data_dir;
    }

    public String getData_file() {
        return data_file;
    }

    public void setData_file(String data_file) {
        this.data_file = data_file;
    }

    public String getData_type() {
        return data_type;
    }

    public void setData_type(String data_type) {
        this.data_type = data_type;
    }

    public String getData_format() {
        return data_format;
    }

    public void setData_format(String data_format) {
        this.data_format = data_format;
    }

    public String getArea_name() {
        return area_name;
    }

    public void setArea_name(String area_name) {
        this.area_name = area_name;
    }

    public String getArea_number() {
        return area_number;
    }

    public void setArea_number(String area_number) {
        this.area_number = area_number;
    }

    public String getBuild_name() {
        return build_name;
    }

    public void setBuild_name(String build_name) {
        this.build_name = build_name;
    }

    public String getBuild_number() {
        return build_number;
    }

    public void setBuild_number(String build_number) {
        this.build_number = build_number;
    }

    public String getPainted_numbers() {
        return painted_numbers;
    }

    public void setPainted_numbers(String painted_numbers) {
        this.painted_numbers = painted_numbers;
    }

    public String getData_description() {
        return data_description;
    }

    public void setData_description(String data_description) {
        this.data_description = data_description;
    }
}
